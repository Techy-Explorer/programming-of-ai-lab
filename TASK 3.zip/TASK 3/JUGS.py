# Water Jug Problem using Depth First Search (DFS)
# Problem: 4-liter jug & 3-liter jug → measure exactly 2 liters

# State representation: (x, y)
# x = water in 4L jug
# y = water in 3L jug

MAX_X = 4   # capacity of jug X
MAX_Y = 3   # capacity of jug Y
GOAL = 2    # desired amount

# Keep track of visited states
visited = set()

# Rules are printed on each operation
def print_rule(action, state):
    print(f"Rule Applied: {action} → New State: {state}")

# DFS algorithm
def dfs(state):
    x, y = state
    
    # If goal is reached
    if x == GOAL or y == GOAL:
        print("\n🎉 Goal reached!")
        print(f"Final State: {state}")
        return True
    
    visited.add(state)  # mark current state visited

    # List of possible next states (rules)
    next_states = [
        (MAX_X, y, "Fill Jug X (4L)"),
        (x, MAX_Y, "Fill Jug Y (3L)"),
        (0, y, "Empty Jug X (pour out)"),
        (x, 0, "Empty Jug Y (pour out)"),
        # Pour X → Y
        (x - min(x, MAX_Y - y), y + min(x, MAX_Y - y), "Pour Jug X → Jug Y"),
        # Pour Y → X
        (x + min(y, MAX_X - x), y - min(y, MAX_X - x), "Pour Jug Y → Jug X"),
    ]
    
    # Explore next states
    for nx, ny, action in next_states:
        new_state = (nx, ny)
        if new_state not in visited:
            print_rule(action, new_state)
            if dfs(new_state):
                return True

    return False


# Initial State
start = (0, 0)

print("===== Water Jug Problem: DFS Search =====")
print("Initial State:", start)

# Run DFS
dfs(start)