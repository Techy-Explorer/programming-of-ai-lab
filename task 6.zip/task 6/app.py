from flask import Flask, render_template
from yolo_detection import detect_animals

app = Flask(__name__)

@app.route("/")
def home():
    count = detect_animals("image.jpg")

    # Example coordinates (can be changed)
    latitude = 31.5204
    longitude = 74.3587

    return render_template("index.html",
                           count=count,
                           latitude=latitude,
                           longitude=longitude)

if __name__ == "__main__":
    app.run(debug=True)