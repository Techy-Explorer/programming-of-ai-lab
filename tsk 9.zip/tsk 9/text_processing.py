import nltk
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer

# 1. Ensure necessary NLTK data is downloaded
try:
    nltk.download('punkt', quiet=True)
except Exception:
    pass

# 2. Sample Text
text = "The quick brown foxes are jumping over the lazy dogs."

# 3. Subtask: Tokenization
# Breaking the text into individual words
tokens = word_tokenize(text)
print("Tokens:")
print(tokens)

# 4. Subtask: Stemming
# Reducing words to their root form
stemmer = PorterStemmer()
stemmed_words = [stemmer.stem(word) for word in tokens]

print("\nStemmed Words:")
print(stemmed_words)

# 5. Comparing original vs stemmed
print("\nComparison:")
for original, stemmed in zip(tokens[:5], stemmed_words[:5]):
    print(f"{original} -> {stemmed}")
