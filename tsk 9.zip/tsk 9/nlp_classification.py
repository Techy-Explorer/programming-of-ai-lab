from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

# 1. Initialize the model and vectorizer
model = MultinomialNB()
vectorizer = CountVectorizer()

# 2. Prepare the training data (Subtask: Spam Detection)
# X contains the text messages
# y contains the labels (spam or ham)
X_train = [
    "Win a free gift card now!", 
    "Hey, are we still meeting for lunch?", 
    "Congratulations! You've won a $1000 Walmart gift card.", 
    "Can you send me the report by EOD?", 
    "URGENT: Your account has been compromised, click here to reset.",
    "Let's go for a movie this weekend."
]
y_train = ["spam", "ham", "spam", "ham", "spam", "ham"]

# 3. Transform text data into numerical vectors
X_vectors = vectorizer.fit_transform(X_train)

# 4. Train the model
model.fit(X_vectors, y_train)

# 5. Predict on a new message
new_message = ["Get a free discount on your next purchase!"]
new_message_vector = vectorizer.transform(new_message)
prediction = model.predict(new_message_vector)

print(f"Message: {new_message[0]}")
print(f"Prediction: {prediction[0]}")
