from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

# 1. Initialize the model and vectorizer
model = MultinomialNB()
vectorizer = CountVectorizer()

# 2. Prepare the training data (Subtask: Language Identification)
X_train = [
    "Hello, how are you today?",
    "Bonjour, comment ça va ?",
    "Hola, ¿cómo estás?",
    "Good morning everyone",
    "Salut tout le monde",
    "Buenos días a todos"
]
y_train = ["English", "French", "Spanish", "English", "French", "Spanish"]

# 3. Transform text data into numerical vectors
X_vectors = vectorizer.fit_transform(X_train)

# 4. Train the model
model.fit(X_vectors, y_train)

# 5. Predict on a new sentence
new_sentence = ["¿Qué pasa?"]
new_vector = vectorizer.transform(new_sentence)
prediction = model.predict(new_vector)

print(f"Sentence: {new_sentence[0]}")
print(f"Detected Language: {prediction[0]}")
