from flask import Flask, render_template, request, jsonify
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import nltk
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer

# Initialize Flask
app = Flask(__name__)

# --- Setup NLP Models ---
# 1. Spam Detection Model
spam_vectorizer = CountVectorizer()
spam_model = MultinomialNB()
X_spam = [
    "Win a free gift card now!", "Meeting at 5pm", 
    "Congratulations! You won $1000", "Hey, are we still meeting?",
    "URGENT: Reset your account", "Let's go for a movie",
    "Get a free discount code", "Can you send the report?",
    "Free entry to win a car", "Lunch is at 1pm"
]
y_spam = ["spam", "ham", "spam", "ham", "spam", "ham", "spam", "ham", "spam", "ham"]
spam_model.fit(spam_vectorizer.fit_transform(X_spam), y_spam)

# 2. Sentiment Analysis Model
sent_vectorizer = CountVectorizer()
sent_model = MultinomialNB()
X_sent = ["I love this", "This is horrible", "Amazing experience", "I hate it", "Fantastic", "Very bad"]
y_sent = ["positive", "negative", "positive", "negative", "positive", "negative"]
sent_model.fit(sent_vectorizer.fit_transform(X_sent), y_sent)

# 3. Stemmer
stemmer = PorterStemmer()
try:
    nltk.download('punkt', quiet=True)
except:
    pass

@app.route("/", methods=["GET", "POST"])
def index():
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze():
    text = request.json.get("text", "")
    task = request.json.get("task", "spam")
    
    if not text:
        return jsonify({"error": "No text provided"}), 400
    
    result = ""
    details = {}
    
    if task == "spam":
        vec = spam_vectorizer.transform([text])
        pred = spam_model.predict(vec)[0]
        result = f"Result: {pred.upper()}"
        details = {"type": "Classification", "category": pred}
        
    elif task == "sentiment":
        vec = sent_vectorizer.transform([text])
        pred = sent_model.predict(vec)[0]
        result = f"Sentiment: {pred.upper()}"
        details = {"type": "Sentiment Analysis", "category": pred}
        
    elif task == "process":
        tokens = word_tokenize(text)
        stemmed = [stemmer.stem(w) for w in tokens]
        result = f"Processed {len(tokens)} words."
        details = {"tokens": tokens, "stemmed": stemmed}
        
    return jsonify({
        "result": result,
        "details": details
    })

if __name__ == "__main__":
    app.run(debug=True, port=5000)
