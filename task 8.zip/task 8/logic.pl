% Propositional Logic Facts & Rules

space_related(mars).
space_related(moon).
space_related(stars).

interesting(X) :- space_related(X).