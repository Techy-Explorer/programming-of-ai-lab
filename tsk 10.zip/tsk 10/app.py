from flask import Flask, render_template, request, jsonify
import numpy as np
from gensim.models import Word2Vec
from sklearn.neural_network import MLPClassifier
import os

app = Flask(__name__)

training_data = [
    ("what is on the menu", "menu"),
    ("show me the food list", "menu"),
    ("i want to see the drinks", "menu"),
    ("what can i eat", "menu"),
    ("book a table for tonight", "reservation"),
    ("i want to make a reservation", "reservation"),
    ("is there a free table at 7pm", "reservation"),
    ("can i reserve a spot", "reservation"),
    ("where is my order", "order"),
    ("track my food delivery", "order"),
    ("how long until my pizza arrives", "order"),
    ("status of my order", "order")
]

sentences = [text.split() for text, label in training_data]
w2v_model = Word2Vec(sentences, min_count=1, vector_size=10, window=5)

def get_vector(text):
    words = text.split()
    vectors = [w2v_model.wv[word] for word in words if word in w2v_model.wv]
    if not vectors:
        return np.zeros(10)
    return np.mean(vectors, axis=0)

X = np.array([get_vector(text) for text, label in training_data])
labels = [label for text, label in training_data]
label_map = {"menu": 0, "reservation": 1, "order": 2}
y = np.array([label_map[l] for l in labels])

model = MLPClassifier(hidden_layer_sizes=(16, 8), activation='relu', solver='adam', max_iter=500)
model.fit(X, y)

responses = {
    "menu": "Our current menu features Grilled Salmon, Truffle Pasta, and our signature Wagyu Burger. Would you like to see the full list?",
    "reservation": "I can certainly help with that. We have tables available for tonight. What time and for how many people should I book?",
    "order": "Your order #4582 is currently being prepared by our chef and will be out for delivery in approximately 15 minutes."
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    user_input = request.json.get('message').lower()
    vector = get_vector(user_input).reshape(1, -1)
    prediction = model.predict(vector)[0]
    
    intents = ["menu", "reservation", "order"]
    intent = intents[prediction]
    
    return jsonify({"reply": responses[intent]})

if __name__ == '__main__':
    app.run(debug=True, port=5001)
