document.addEventListener('DOMContentLoaded', () => {
    const chatContainer = document.getElementById('chat-container');
    const userInput = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');

    const addMessage = (message, isBot = false) => {
        const msgDiv = document.createElement('div');
        msgDiv.classList.add('message');
        msgDiv.classList.add(isBot ? 'bot-message' : 'user-message');
        msgDiv.classList.add('fade-in');
        
        msgDiv.innerHTML = `<div class="message-content">${message}</div>`;
        
        chatContainer.appendChild(msgDiv);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    };

    const showTypingIndicator = () => {
        const indicator = document.createElement('div');
        indicator.id = 'typing-indicator';
        indicator.classList.add('message', 'bot-message', 'fade-in');
        indicator.innerHTML = `
            <div class="typing-indicator">
                <div class="dot"></div>
                <div class="dot"></div>
                <div class="dot"></div>
            </div>
        `;
        chatContainer.appendChild(indicator);
        chatContainer.scrollTop = chatContainer.scrollHeight;
        return indicator;
    };

    const handleSend = async () => {
        const text = userInput.value.trim();
        if (!text) return;

        addMessage(text, false);
        userInput.value = '';

        const indicator = showTypingIndicator();

        try {
            const response = await fetch('/ask', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message: text })
            });

            const data = await response.json();
            
            if (indicator.parentNode) {
                chatContainer.removeChild(indicator);
            }
            addMessage(data.reply, true);
        } catch (error) {
            console.error('Error:', error);
            if (indicator.parentNode) {
                chatContainer.removeChild(indicator);
            }
            addMessage("I'm sorry, I'm having trouble connecting to the knowledge base. Please try again.", true);
        }
    };

    sendBtn.addEventListener('click', handleSend);
    
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSend();
        }
    });
});
