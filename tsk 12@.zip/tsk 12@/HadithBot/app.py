from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
import os
import re

app = Flask(__name__)

# Load the dataset
dataset_path = os.path.join(os.path.dirname(__file__), 'dataset.csv')
df = pd.read_csv(dataset_path)

# Preprocessing function as per HadithBot.ipynb
def clean_text(text):
    text = str(text).lower()
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

# Initialize the embedding model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Pre-calculate embeddings for all questions
print("Embedding Hadith questions...")
questions = df['question'].apply(clean_text).tolist()
question_embeddings = model.encode(questions)

# Create FAISS index
dimension = question_embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(np.array(question_embeddings).astype('float32'))

def get_best_match(user_query):
    # Clean the query
    cleaned_query = clean_text(user_query)
    # Embed the query
    query_embedding = model.encode([cleaned_query])
    
    # Search the FAISS index
    D, I = index.search(np.array(query_embedding).astype('float32'), k=1)
    
    best_match_idx = I[0][0]
    return df.iloc[best_match_idx]['hadith']

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    data = request.json
    user_message = data.get('message', '')
    
    if not user_message:
        return jsonify({"reply": "Please ask a question about Hadith or purification."})
    
    try:
        reply = get_best_match(user_message)
        return jsonify({"reply": reply})
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"reply": "I'm sorry, I couldn't find a relevant Hadith for your query."})

if __name__ == '__main__':
    # Use port 5003 for HadithBot to avoid conflicts
    app.run(debug=True, port=5003)
