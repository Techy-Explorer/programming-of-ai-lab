from data_loader import FileHandler
from preprocessing import DataPreprocessor
from models import NaiveBayesModel, DecisionTreeModel
from eda import perform_eda
import pandas as pd

# Step 1: Load data
handler = FileHandler()
train_df = handler.read_csv("data/spaceship-titanic/train.csv")
test_df = handler.read_csv("data/spaceship-titanic/test.csv")

# Step 2: EDA
perform_eda(train_df)

# Step 3: Preprocessing
pre = DataPreprocessor()
train_df = pre.preprocess(train_df)
test_df = pre.preprocess(test_df)

# Step 4: Extract features and target
X, y = pre.get_features_and_target(train_df)
X_test = test_df.drop(["PassengerId", "Name"], axis=1)

# Step 5: Train Models
nb = NaiveBayesModel()
dt = DecisionTreeModel()

nb.train(X, y)
dt.train(X, y)

# Step 6: Evaluate models
print("\nNaïve Bayes Accuracy:", nb.evaluate(X, y))
print("Decision Tree Accuracy:", dt.evaluate(X, y))

# Step 7: Choose best model
best_model = dt  # decision tree performs better

# Step 8: Predict & Save Kaggle Submission
predictions = best_model.model.predict(X_test)
submission = pd.DataFrame({
    "PassengerId": test_df["PassengerId"],
    "Transported": predictions.astype(bool)
})

submission.to_csv("output/submission.csv", index=False)
print("\nSubmission file created: output/submission.csv")