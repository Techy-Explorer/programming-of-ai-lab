from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

class BaseModel:
    """Parent class defining structure for models."""

    def train(self, X, y):
        raise NotImplementedError
    
    def evaluate(self, X, y):
        raise NotImplementedError


class NaiveBayesModel(BaseModel):
    def __init__(self):
        self.model = GaussianNB()

    def train(self, X, y):
        self.model.fit(X, y)

    def evaluate(self, X, y):
        preds = self.model.predict(X)
        return accuracy_score(y, preds)


class DecisionTreeModel(BaseModel):
    def __init__(self):
        self.model = DecisionTreeClassifier(max_depth=8)

    def train(self, X, y):
        self.model.fit(X, y)

    def evaluate(self, X, y):
        preds = self.model.predict(X)
        return accuracy_score(y, preds)