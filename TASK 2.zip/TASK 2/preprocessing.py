import pandas as pd
from sklearn.preprocessing import LabelEncoder

class DataPreprocessor:
    """Handles missing values, encoding, and feature processing."""

    def __init__(self):
        self.encoder = LabelEncoder()

    def preprocess(self, df):
        df["HomePlanet"].fillna("Unknown", inplace=True)
        df["CryoSleep"].fillna(False, inplace=True)
        df["Destination"].fillna("Unknown", inplace=True)
        df["Age"].fillna(df["Age"].median(), inplace=True)
        df["VIP"].fillna(False, inplace=True)

        # Encoding categorical columns
        for col in ["HomePlanet", "Destination"]:
            df[col] = self.encoder.fit_transform(df[col])

        # Convert boolean to int
        df["CryoSleep"] = df["CryoSleep"].astype(int)
        df["VIP"] = df["VIP"].astype(int)

        return df

    def get_features_and_target(self, df):
        X = df.drop(["Transported", "PassengerId", "Name"], axis=1)
        y = df["Transported"].astype(int)
        return X, y