import matplotlib.pyplot as plt
import seaborn as sns

def perform_eda(df):
    print("\n--- BASIC INFO ---")
    print(df.info())
    
    print("\n--- MISSING VALUES ---")
    print(df.isnull().sum())

    plt.figure(figsize=(6,4))
    sns.countplot(x=df["Transported"])
    plt.title("Transported Distribution")
    plt.show()