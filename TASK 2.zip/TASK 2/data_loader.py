import pandas as pd

class FileHandler:
    """Handles reading CSV files."""

    def read_csv(self, filepath):
        print(f"Reading file: {filepath}")
        return pd.read_csv(filepath)