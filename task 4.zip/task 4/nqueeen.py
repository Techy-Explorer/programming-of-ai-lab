# N-Queens Problem using Backtracking (Dynamic)
# Lab 4 - Advanced Search Techniques

def is_safe(board, row, col, n):
    """Check if placing a queen at board[row][col] is safe."""
    
    # Check left side of the row
    for c in range(col):
        if board[row][c] == 1:
            return False

    # Check upper-left diagonal
    r, c = row, col
    while r >= 0 and c >= 0:
        if board[r][c] == 1:
            return False
        r -= 1
        c -= 1

    # Check lower-left diagonal
    r, c = row, col
    while r < n and c >= 0:
        if board[r][c] == 1:
            return False
        r += 1
        c -= 1

    return True


def solve_n_queens(board, col, n):
    """Recursive backtracking algorithm."""
    
    # Base case: all queens placed
    if col == n:
        return True

    # Try placing queen in each row of this column
    for row in range(n):
        if is_safe(board, row, col, n):
            board[row][col] = 1   # place queen

            if solve_n_queens(board, col + 1, n):
                return True

            board[row][col] = 0   # backtrack

    return False


def print_board(board, n):
    """Print the chessboard."""
    for row in range(n):
        for col in range(n):
            print("Q" if board[row][col] == 1 else ".", end=" ")
        print()
    print()


# -------- Main Program --------
print("=== N-Queens Problem (Backtracking) ===")
n = int(input("Enter N (size of chessboard): "))

board = [[0 for _ in range(n)] for _ in range(n)]

if solve_n_queens(board, 0, n):
    print("\nSolution Found:")
    print_board(board, n)
else:
    print("No solution exists for N =", n)